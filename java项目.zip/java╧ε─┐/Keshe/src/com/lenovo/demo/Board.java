package com.lenovo.demo;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 * ��Ϸ������UI���㷨����
 * @author Lee
 *
 */
public class Board {
	static Game game;
    static int repeat;
    static int times = 0;
    public static int width = Toolkit.getDefaultToolkit().getScreenSize().width;
    public static int height = Toolkit.getDefaultToolkit().getScreenSize().height;

    public static void main(String[] args) {
    	Music.Music1();
        Music.Music2();
        Music.Music3();
        Music moth = new Music(1);
        //���ô���
        JFrame f = new JFrame("Ȥζ���¡�������2019������С��Ϸ�����������ߣ������");
        f.setSize(1000, 700);
        f.setLocation((width - 1000) / 2 - 150, (height - 700) / 2);
        f.setLayout(null);
        f.setIconImage(new ImageIcon("icons/07.png").getImage());
        f.setBackground(Color.white);
        //����ͼƬ���
        JLabel i1 = new JLabel();
        ImageIcon i = new ImageIcon("images/Logo.jpg");
        i1.setIcon(i);
        i1.setBounds(10, 0, 300, 300);
        f.add(i1);
        Label l2 = new Label("Ȥ ζ �� ��");
        l2.setForeground(Color.red);
        l2.setSize(750, 150);
        l2.setLocation(320, 0);
        l2.setFont(new Font("����", Font.BOLD, 60));
        Label l22 = new Label("�����·�ѡ����Ϸ�Ѷ�");
        l22.setForeground(Color.red);
        l22.setSize(300, 35);
        l22.setLocation(400, 150);
        l22.setFont(new Font("����", Font.CENTER_BASELINE, 15));
        f.add(l2);
        f.add(l22);
        JRadioButton b31 = new JRadioButton("��(1-10)");
        JRadioButton b32 = new JRadioButton("һ��(1-100)");
        JRadioButton b33 = new JRadioButton("����(1-1K)");
        JRadioButton b34 = new JRadioButton("��ը(1-1W)");
        b31.setLayout(null);
        b32.setLayout(null);
        b33.setLayout(null);
        b34.setLayout(null);
        b31.setSelected(true);
        b31.setBounds(320, 190, 110, 30);
        b32.setBounds(430, 190, 110, 30);
        b33.setBounds(540, 190, 110, 30);
        b34.setBounds(650, 190, 110, 30);
        ButtonGroup bg3 = new ButtonGroup();
        
        Button s1 = new Button("��ʼ");
        s1.setSize(150, 50);
        s1.setLocation(330, 220);
        s1.setBackground(Color.PINK);
        s1.setForeground(Color.BLUE);
        s1.setFont(new Font("����", Font.CENTER_BASELINE, 18));
        
        Button s2 = new Button("�˳�");
        s2.setSize(150, 50);
        s2.setLocation(490, 220);
        s2.setBackground(Color.PINK);
        s2.setForeground(Color.BLUE);
        s2.setFont(new Font("����", Font.CENTER_BASELINE, 18));
        
        Button s3 = new Button("��/���� ���ֿ���̨");
        s3.setBackground(Color.PINK);
        s3.setForeground(Color.BLUE);
        s3.setFont(new Font("����", Font.CENTER_BASELINE, 18));
        s3.setSize(200, 50);
        s3.setLocation(750, 160);
        f.add(s3);
        
        bg3.add(b31);
        bg3.add(b32);
        bg3.add(b33);
        bg3.add(b34);
        f.add(b31);
        f.add(b32);
        f.add(b33);
        f.add(b34);
        Label tip = new Label();
        tip.setText("              ��ֱ���ڴ�������Ĵ𰸡�����");
        tip.setForeground(Color.MAGENTA);
        tip.setFont(new Font("����", Font.LAYOUT_RIGHT_TO_LEFT, 25));
        Button tijiao = new Button();
        tijiao.setLabel("�ύ��");
        tijiao.setBackground(Color.PINK);
        tijiao.setForeground(Color.BLUE);
        tijiao.setFont(new Font("����", Font.BOLD, 20));
        tijiao.setBounds(750, 220, 200, 50);
        f.add(s1);
        f.add(s2);
        f.add(tip);
        f.add(tijiao);
        JTextArea t2 = new JTextArea();
        t2.setBackground(Color.getColor(null));
        t2.setSize(250, 350);
        t2.setLocation(10, 320);
     // String g =
        t2.setText("��Ϸ����:            \n" + "1.ѡ��������ս���ѶȲ����¿�ʼ\n" + "2.���������²������\n" + "3.ϵͳ��ʾ�²�������𰸵Ĺ�ϵ\n"
                + "4.��²�������ٴγ���\n" + "5.�²�ɹ����·���ʾ�²����ô���\n" + "\n" + "NEW�����ֿ���̨������������\n\n�˳������˳���ť\n" + "\n\n\n\n"
                + "\n\n���ߣ������\n����vx��lqh850246337\n");
        t2.setFont(new Font("����", Font.CENTER_BASELINE, 14));
        t2.setCaretColor(Color.BLUE);
        f.add(t2);
        JLabel i51 = new JLabel();
        ImageIcon i510 = new ImageIcon("images/demo.jpg");
        ImageIcon i511 = new ImageIcon("images/success.jpg");
        ImageIcon i512 = new ImageIcon("images/demobig.jpg");
        ImageIcon i513 = new ImageIcon("images/demosmall.jpg");
        i51.setIcon(i510);
        i51.setBounds(320, 300, 380, 380);
        f.add(i51);
        JTextField answer = new JTextField();
        answer.setSize(200, 250);
        answer.setLocation(750, 300);
        answer.setBackground(Color.PINK);
        answer.setCaretColor(Color.YELLOW);
        answer.setFont(new Font("����", Font.CENTER_BASELINE, 60));
        answer.setText("0");
        f.add(answer);
        Label l7 = new Label();
        l7.setFont(new Font("����", Font.CENTER_BASELINE, 16));
        l7.setBounds(750, 560, 200, 130);
        l7.setText("��ǰ�ѳ��Դ���Ϊ�� " + times + " ��");
        f.add(l7);
        
     // ���ֿ���̨
        JFrame music = new JFrame();
        music.setBounds((width - 1000) / 2 + 850, (height - 700) / 2, 300, 600);
        music.setTitle("���ֿ���̨");
        JLabel tm = new JLabel();
        tm.setBounds(45, 0, 200, 100);
        tm.setText("���ֿ���̨");
        music.setBackground(Color.CYAN);
        tm.setFont(new Font("����", Font.CENTER_BASELINE, 36));
        tm.setForeground(Color.BLUE);
        music.add(tm);
        
        JRadioButton m1 = new JRadioButton("Ĭ��������");
        JRadioButton m2 = new JRadioButton("�Ͻ�");
        JRadioButton m3 = new JRadioButton("�տ���Ҳ");
        JRadioButton m4 = new JRadioButton("�Ϸ�����");
        m1.setSelected(true);
        m1.setBounds(40, 120, 200, 30);
        m2.setBounds(40, 160, 200, 30);
        m3.setBounds(40, 200, 200, 30);
        m4.setBounds(40, 240, 200, 30);
        m1.setFont(new Font("����", Font.CENTER_BASELINE, 16));
        m2.setFont(new Font("����", Font.CENTER_BASELINE, 12));
        m3.setFont(new Font("����", Font.CENTER_BASELINE, 16));
        m4.setFont(new Font("����", Font.CENTER_BASELINE, 16));
        music.add(m1);
        music.add(m2);
        music.add(m3);
        music.add(m4);
        
        JButton play = new JButton();
        play.setText("����");
        play.setBounds(30, 380, 220, 60);
        play.setBackground(Color.PINK);
        play.setForeground(Color.YELLOW);
        play.setFont(new Font("����", Font.BOLD, 28));
        music.add(play);
        
        JLabel mup = new JLabel();
        ImageIcon mppd = new ImageIcon("images/musicdoo.gif");
        ImageIcon mppp = new ImageIcon("images/musicdoo2.gif");
        mup.setIcon(mppd);
        mup.setBounds(30, 275, 220, 100);
        music.add(mup);
        
        JButton pause = new JButton();
        pause.setText("ֹͣ");
        pause.setBounds(30, 450, 220, 60);
        pause.setBackground(Color.PINK);
        pause.setForeground(Color.YELLOW);
        pause.setFont(new Font("����", Font.BOLD, 28));
        music.add(pause);
        
        ButtonGroup mcc = new ButtonGroup();
        mcc.add(m1);
        mcc.add(m2);
        mcc.add(m3);
        mcc.add(m4);
        
        music.setIconImage(new ImageIcon("icons/07.png").getImage());
        
        music.setLayout(null);
        music.setVisible(true);
        
        // ���ֿ���̨��ť������
        s3.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                // TODO Auto-generated method stub
                if (music.isVisible()) {
                    music.setVisible(false);
                } else {
                    music.setVisible(true);
                }
            }

        });

     // ���ֿ���̨������
        play.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                // TODO Auto-generated method stub
                mup.setIcon(mppd);
                if (m1.isSelected()) {
                    Music mji = new Music(1);
                } else if (m2.isSelected()) {

                    Music.Music1();
                } else if (m3.isSelected()) {

                    Music.Music2();
                } else if (m4.isSelected()) {

                    Music.Music3();
                }

            }

        });
        pause.addActionListener(new ActionListener() {
        	
        	@Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                mup.setIcon(mppp);
                Music.pause();
            }

        });
        
     // f.setIconImage("/images/icon.icon");
        // ���ô���ɼ�
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        
     // ��������
        // Desktop.getDesktop().open(new File("/images/start.jpg"));
        s1.addActionListener(new ActionListener() {
        	
        	 @Override
        	 
        	 public void actionPerformed(ActionEvent start) {
                 // TODO Auto-generated method stub �˴�����start��������Ϸ�¼�
                 times = 0;
                 f.setTitle("Ȥζ���¡�������2019������С��Ϸ�����������ߣ������       �� �� Ϸ �� ��");
                 l7.setText("��ǰ���Դ���Ϊ�� " + times + " ��");
                 i51.setIcon(i510);
                 if (b31.isSelected()) {
                     game = new Game();
                 } else if (b32.isSelected()) {
                     game = new Game(1);
                 } else if (b33.isSelected()) {
                     game = new Game("");
                 } else if (b34.isSelected()) {
                     game = new Game(1, 1);
                 }
                 
        }
        });
        
        tijiao.addActionListener(new ActionListener() {
        	
        	@Override
        	public void actionPerformed(ActionEvent reset) {
        		// TODO Auto-generated method stub �˴������ύ���¼�
        		// do {
        		
        		int inpeat = Integer.valueOf(answer.getText());
                repeat = game.setA(inpeat);
                if (repeat == 0) {
                    i51.setIcon(i511);
                    times = times + 1;
                    JOptionPane.showMessageDialog(f, "��ϲ����,��¶�����\n��ȷ�𰸾���" + inpeat + "\n��һ������" + times + "��Ŷ", "�¶���",1);
                    f.setTitle("Ȥζ���ʡ�������2019������С��Ϸ�����������ߣ������");
                } else if (repeat == 1) {
                    i51.setIcon(i512);
                } else if (repeat == 2) {
                    i51.setIcon(i513);
                }
                times++;
                l7.setText("��ǰ���Դ���Ϊ�� " + times + " ��");
                answer.setText(null);
            }
        });
        
        s2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent reset) {
                // TODO Auto-generated method stub �˴��������ô����¼�
                System.exit(0);
            }
        });
        
    }
    
 // private static void Start() {
    // // TODO Auto-generated method stub
    //
    // }
}