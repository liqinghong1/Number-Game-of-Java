package com.lenovo.demo;

/**
 * ��Ϸ�����ں�
 * @author Lee
 *
 */
public class Game {

	private int a;
    private int b;
    
    public Game() {
        b = (int)(Math.random()*10+1);
    }
    
    public Game(int r) {
        b = (int)(Math.random()*100+1);
    }
    public Game(String abc) {
        b = (int)(Math.random()*1000+1);
    }
    public Game(int x,int y) {
        b = (int)(Math.random()*10000+1);
    }
    
    public int getA(int a) {
        int abo=4;
        if(a==b) {
            abo = 0;
        }else if(a>b){
            abo = 1;
        }else if(a<b) {
            abo = 2;
        }
        return abo;
    }
    
    public int setA(int abc) {
        this.a=abc;
        int repe = getA(a);
        return repe;
    }
}
