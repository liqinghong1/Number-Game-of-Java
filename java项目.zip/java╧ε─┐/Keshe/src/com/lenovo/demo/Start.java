package com.lenovo.demo;

import java.awt.Color;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
/**
 * ��Ϸ���ؽ���
 * @author Lee
 *
 */
public class Start {
	 public static int width = Toolkit.getDefaultToolkit().getScreenSize().width;
     public static int height = Toolkit.getDefaultToolkit().getScreenSize().height;

     static JFrame start;
     static JProgressBar in;
     public static void main(String[] args) {
         start = new JFrame();
         start.setBounds((width-420)/2, (height-350)/2, 420, 385);
         start.setUndecorated(true);
         start.setLayout(null);
         
         JLabel startjpg = new JLabel();
         ImageIcon jpg = new ImageIcon("images/start.jpg");
         startjpg.setIcon(jpg);
         startjpg.setBounds(0, 0, 420, 360);
         start.add(startjpg);
         
         in = new JProgressBar();
         in.setBounds(0, 360, 420, 25);
         in.setMaximum(10);
         in.setMinimum(0);
         in.setStringPainted(true);
         in.setBackground(Color.GREEN);
         start.add(in);
         start.setVisible(true);
     }
     
     public static int jindu() throws InterruptedException {
         for (int k = 0; k < 101; k++) {
                 if (k < 40) {
                     int h = (int) (Math.random() * 150 + 1);
                         Thread.sleep(h);
                 } else {
                         Thread.sleep(5);
                 }
             in.setValue(k);
             if (k == 100) {
                 start.dispose();
                 Board.main(null);
                 
                 break;
             }
             
         }
         return 0;
     }
}