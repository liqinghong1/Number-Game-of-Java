package com.lenovo.demo;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.net.URI;
import java.net.URL;

import javax.swing.JFrame;
/**
 * ����������
 */
public class Music extends JFrame{
	/**
     * 
     */
	private static final long serialVersionUID = 1L;
    static AudioClip aau;
    static AudioClip aai;
    static AudioClip aao;
    static AudioClip aap;
    static File f;
    static URI uri;
    static URL url;
    
 // Music(){
    // bgMusic();
    // }
    @SuppressWarnings("null")
    public Music(int a) {
    	
    	try {
            f = new File("music/Let's not fall in love.wav");
            uri = f.toURI();
            url = uri.toURL(); // ������ַ
            aau = null;
            aau = Applet.newAudioClip(url);
            aai.stop();
        aao.stop();
        aap.stop();
        aau.loop(); // ѭ������
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @SuppressWarnings("null")
    public static void Music1() {

        try {

            f = new File("music/�Ͻ�.wav");
            uri = f.toURI();
            url = uri.toURL(); // ������ַ
            aai = null;
            aai = Applet.newAudioClip(url);
            aau.stop();
        aao.stop();
        aap.stop();
        aai.loop(); // ѭ������
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @SuppressWarnings("null")
    public static void Music2() {

        try {
            f = new File("music/�տ���Ҳ.wav");
            uri = f.toURI();
            url = uri.toURL(); // ������ַ
            aao = null;
            aao = Applet.newAudioClip(url);
            aau.stop();
        aai.stop();
        aap.stop();
        aao.loop(); // ѭ������
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @SuppressWarnings("null")
    public static void Music3() {

        try {
            f = new File("music/�Ϸ�����.wav");
            uri = f.toURI();
            url = uri.toURL(); // ������ַ
            aap = null;
            aap = Applet.newAudioClip(url);
            aai.stop();
        aao.stop();
        aau.stop();
        aap.loop(); // ѭ������
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void pause() {
        aai.stop();
        aao.stop();
        aap.stop();
        aau.stop();
    }


}