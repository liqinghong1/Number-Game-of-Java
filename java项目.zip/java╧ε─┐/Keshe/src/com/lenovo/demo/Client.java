package com.lenovo.demo;
/**
 * �û��ͻ���
 * @author Lee
 *
 */
public class Client {
public static void main(String[] args){
	//Start jk = new Start();
	Start.main(null);
	try{
		Start.jindu();
	}catch(InterruptedException e){
		//TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

